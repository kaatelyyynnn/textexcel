package textExcel;

public class RealCell implements Cell{
	private String original;
	// constructor
	public RealCell(String s) {
		original = s;
	}
	
	//adds spaces if cell text is less than 10 characters 
	public String abbreviatedCellText() {
		String s = getDoubleValue() + "         ";
		return s.substring(0,10);
	}
	
	//returns full cell text of 10 characters
	public String fullCellText() {
		return getOrig();
	}
	
	//converts String to double value
	public double getDoubleValue() {
		 return Double.parseDouble(original);
	    }
	
	//returns original value
	public String getOrig() {
		 return original;
	 }
	 
	 
}

