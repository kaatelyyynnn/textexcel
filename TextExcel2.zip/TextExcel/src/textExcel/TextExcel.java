/* @author Katelyn Chang
 * @version 2/28/22
 * APCS 
 */

package textExcel;

import java.io.FileNotFoundException;
import java.util.Scanner;

// Update this file with your own code.

public class TextExcel
{

	public static void main(String[] args)
	{
	    //implements scanner for commands
		    System.out.println("Please enter your expression new");
          	Scanner askforinput = new Scanner(System.in);
         	String thencontinue = askforinput.nextLine();
		    Spreadsheet sheet= new Spreadsheet();
		      while(!thencontinue.equalsIgnoreCase("quit")) {
		    	  System.out.println(sheet.processCommand(thencontinue));
		    	  System.out.print("Enter a Command: ");
		    	  thencontinue = askforinput.nextLine();
		    	
		      }
		      askforinput.close(); 
	}
}
