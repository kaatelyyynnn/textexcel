package textExcel;

public class FormulaCell extends RealCell{ 
	Cell [][] arrsheet;
	
	public FormulaCell(String s, Cell[][]arrsheet) {
		super(s);
		this.arrsheet = arrsheet;
	}
	
	// text for individual cell inspection, not truncated or padded
	public String fullCellText() {
	  return getOrig();
	}
	
	//gets double values of cells
	public double getDoubleValue() {
    String[] array = getOrig().split(" ");
		
		double answer = 0;
		if(array.length == 4) {
	              answer = Sum();
			//returns average of value
	        if(array[1].toLowerCase().equals("avg")) {
				return Avg();
			}
		}
		else {	
		//cycles through every cell until finds particular cell for operation
		for(int i = 1; i < array.length; i += 2) {
			if(array[i].charAt(0) >= 65) {
				Location loc = new SpreadsheetLocation(array[i]);	
				array[i]  = arrsheet[loc.getRow()][loc.getCol()].abbreviatedCellText();
			}
			//adds cell value
			if(array[i-1].equals("+") || array[i-1].equals("(") ){
				answer += Double.parseDouble(array[i]);
			}
			//subtracts cell value
			else if(array[i-1].equals("-")) {
				answer -= Double.parseDouble(array[i]);
			}
			//multiplies cell value
			else if(array[i-1].equals("*")) {
				answer *= Double.parseDouble(array[i]);
			}
			//divides cell value
			else if(array[i-1].equals("/")) {
				answer /= Double.parseDouble(array[i]);
			}
		}
		}
		return answer;
	}

	//deals with sum
	public double Sum() {
		String[] array = getOrig().split(" ");
		double answer = 0;
		String[] nums = array[2].split("-");
		Location begin = new SpreadsheetLocation(nums [0]);
		Location end = new SpreadsheetLocation(nums [1]);
		for(int row = begin.getRow(); row <= end.getRow(); row++) {
			for(int col = begin.getCol(); col <= end.getCol(); col++) {
				answer += Double.parseDouble(arrsheet[row][col].abbreviatedCellText());
			}
		}
		return answer;
}
	//deals with average
	public double Avg() {
		String[] array = getOrig().split(" ");
		double answer=0;
		int n = 0;
		String[] nums = array[2].split("-");
		Location begin = new SpreadsheetLocation(nums[0]);
		Location end = new SpreadsheetLocation(nums[1]);
		for(int row = begin.getRow(); row <= end.getRow(); row++) {
			for(int col = begin.getCol(); col <= end.getCol(); col++) {
				answer += Double.parseDouble(arrsheet[row][col].abbreviatedCellText());
				n++;
			}
		}
		return answer/n;
	}
}

		
		
