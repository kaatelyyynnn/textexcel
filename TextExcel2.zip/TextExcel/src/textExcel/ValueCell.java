package textExcel;

public class ValueCell extends RealCell{
	
	public ValueCell(String original) {
		//takes string through super class of Real Cell
		super(original);
	}
	public String fullCellText() {
		//inherited from real cell
		return getOrig();
	}
}
