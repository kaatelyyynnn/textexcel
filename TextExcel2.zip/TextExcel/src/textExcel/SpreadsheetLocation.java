/* @author Katelyn Chang
 * @version 2/28/22
 * APCS 
 */

package textExcel;


public class SpreadsheetLocation implements Location
{ 
	private int row;
	private int col;
	private String name;
	// constructor
	public SpreadsheetLocation(String cellName)
    {
//set the row + col, parse the index command
	//capitalizes cell name
    	cellName = cellName.toUpperCase();
    	row= Integer.parseInt(cellName.substring(1))-1;
    	col= cellName.charAt(0)-65;
    }
	
	@Override
    public int getRow()
    {
  
        // TODO Auto-generated method stub
        return row;
  
    }

    @Override
    public int getCol()
    {
        // TODO Auto-generated method stub
        return col;
    }
  

}