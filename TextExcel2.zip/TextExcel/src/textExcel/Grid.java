package textExcel;

//*******************************************************
//DO NOT MODIFY THIS FILE!!!
//*******************************************************

public interface Grid 
{
	
	// Grid interface, must be implemented by your Spreadsheet class
	String processCommand(String command); 
	int getRows();
	int getCols(); 
	Cell getCell(Location loc);
	String getGridText(); 
}
