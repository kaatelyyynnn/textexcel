package textExcel;

public class TextCell implements Cell{

	private String original;
	// constructor
	public TextCell(String original) {
		this.original = original;
	}
	//returns original code
	public String fullCellText() {
		return original;
	}
	//returns abbreviated cell text (10 spaces)
	public String abbreviatedCellText() {
		String s= original.substring(1,original.length()-1);
		s += "          ";
		return s.substring(0,10);
		
	}
}

