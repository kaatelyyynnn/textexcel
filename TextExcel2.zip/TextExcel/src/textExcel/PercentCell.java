package textExcel;

public class PercentCell extends RealCell{
	private String original;
	
	//takes string through Real Cell constructor to make sure 10 characters
	public PercentCell(String s) {
		super(s);
	}
	
	//turns abbreviated cell text into percentage value
	public String abbreviatedCellText() {
		String s = (int)(getDoubleValue()* 100) + "%          ";
		return s.substring(0,10);
	}
	//text for individual cell inspection, not truncated or padded
	public String fullCellText() {
		return getDoubleValue() + "";
	}
    
	//takes percent value into array --> parses into double and returns decimal value
	public double getDoubleValue() {
    	String[] arr = getOrig().split("%");
    	return Double.parseDouble(arr[0])/100;
    	
    }
    
}
    
