/* @author Katelyn Chang
 * @version 2/28/22
 * APCS
 */

package textExcel;

import java.lang.reflect.Array;

public class Spreadsheet implements Grid
{
	private int rows;
	private int col;
	private Cell[][] arrsheet;

//constructor
	public Spreadsheet() {
		//initialize array of 20 empty cells
		arrsheet= new Cell[getRows()][getCols()];
		for (int row=0; row<getRows();row++) {
			for (int col=0;col<getCols();col++) {
				 Cell c = new EmptyCell();
				arrsheet[row][col]= c;
			}	
		}
}
	
	@Override
	public String processCommand(String command){
		
		//parse the string, into an index, x and y 
				//returns nothing if contains nothing
			if (command.equals("")) {
				return "";
			}
			if (command.contains("=")){
					//assign value
				    return doCommand(command);
				}
				//clears entire spreadsheet
				else if (command.toLowerCase().contains("clear")){
					if (command.toLowerCase().equals("clear")) {
						return cleargrid(command);
					}else {
					// clear one cell
						return clearcell(command);
					}
				  }else {
					  //returns value inside cell
					return cellInspect(command);
					
				}
			}
	
	//returns what's in a particular cell
	public String cellInspect (String cell) {
		Location loc = new SpreadsheetLocation(cell);
		return (getCell(loc)).fullCellText();
	}
	
	//checks which operation, which object of the cell
	public String doCommand(String command) {
		String[] array=command.split(" ",3);
		Location loc = new SpreadsheetLocation(array[0]);
			Cell s; 
			// if text cell
			if (array[2].startsWith("\"")) {
				s = new TextCell(array[2]);
			}
			//if percent cell
			else if(array[2].endsWith("%")) {
				s = new PercentCell(array[2]);
				
			}
			// if formula cell
			else if(array[2].startsWith("(")) {
					s = new FormulaCell(array[2], arrsheet);
			}
			// if value cell
			else {
				s = new ValueCell(array[2]);
				s.abbreviatedCellText();
			}
			arrsheet[loc.getRow()][loc.getCol()] = s;
			return getGridText();
		}
	
	//clear whole grid
	public String cleargrid(String command) {
		for(int row = 0; row< arrsheet.length;row++) {
			for(int col = 0; col < arrsheet[0].length; col++) {
				Cell cell = new EmptyCell();
				arrsheet[row][col] = cell;
			}
		} 
	return getGridText();
  }
	
  //clear a specific cell
  public String clearcell(String command) {
	  String[] split = command.split(" ");
		SpreadsheetLocation loc = new SpreadsheetLocation(split[1]);
		Cell cell = new EmptyCell();
		arrsheet[loc.getRow()][loc.getCol()] = cell;
		
		return getGridText();
  }
	
  	//returns amount of rows
	@Override
	public int getRows()
	{
		return 20;
	}
	//returns amount of columns
	@Override
	public int getCols()
	{
		return 12;
	}

	//gets location (rows/col) of cell
	@Override
	public Cell getCell(Location loc)
	{   
		return arrsheet[loc.getRow()][loc.getCol()];
	}

    //prints grid of spreadsheet
	@Override
	public String getGridText() {
		String n = "|";
		String head = "   |";
		for(int i = 'A'; i < 'A'+ getCols(); i++) {
		     head += (char) i + "         |";
		}
		String s= head + "\n";
		for(int i = 0; i < getRows(); i++) {
			s += (i+1 + "  ").substring(0, 3) + n;
			for(int j = 0; j < getCols(); j++) {
				s += (arrsheet[i][j].abbreviatedCellText() + "          ").substring(0, 10) +n;
			}
		s += "\n";
		}
		
	 return s;
}
}

